import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
df = pd.read_csv(r"C:\Users\vivekananda\Downloads\global_food_wastage_dataset.csv")

# 1. Top 10 countries by total food waste
top_countries = df.groupby('Country')['Total Waste (Tons)'].sum().sort_values(ascending=False).head(10)
plt.figure(figsize=(10,6))
top_countries.plot(kind='bar', color='orange')
plt.title("Top 10 Countries by Total Food Waste")
plt.xlabel("Country")
plt.ylabel("Total Waste (Tons)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 2. Distribution of food waste by category
category_waste = df.groupby('Food Category')['Total Waste (Tons)'].sum().sort_values(ascending=False)
plt.figure(figsize=(10,6))
category_waste.plot(kind='bar', color='green')
plt.title("Total Food Waste by Category")
plt.xlabel("Food Category")
plt.ylabel("Total Waste (Tons)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 3. Year-wise trend of total food waste
yearly_trend = df.groupby('Year')['Total Waste (Tons)'].sum()
plt.figure(figsize=(10,5))
plt.plot(yearly_trend.index, yearly_trend.values, marker='o', linestyle='-', color='purple')
plt.title("Yearly Trend of Global Food Waste")
plt.xlabel("Year")
plt.ylabel("Total Waste (Tons)")
plt.grid(True)
plt.tight_layout()
plt.show()

# 4. Heatmap of correlation between numeric variables
numeric_cols = ['Total Waste (Tons)', 'Economic Loss (Million $)', 'Avg Waste per Capita (Kg)', 'Population (Million)', 'Household Waste (%)']
corr_matrix = df[numeric_cols].corr()

plt.figure(figsize=(8,6))
sns.heatmap(corr_matrix, annot=True, cmap='YlGnBu', linewidths=0.5)
plt.title("Correlation Heatmap of Food Wastage Factors")
plt.tight_layout()
plt.show()

# 5. Pie chart for household waste contribution
household_contrib = df.groupby('Country')['Household Waste (%)'].mean().sort_values(ascending=False).head(5)
plt.figure(figsize=(7,7))
plt.pie(household_contrib.values, labels=household_contrib.index, autopct='%1.1f%%', startangle=140)
plt.title("Top 5 Countries by Household Waste Contribution")
plt.show()
